#pragma once

namespace co
{
	typedef int IoSentryPtr;
}